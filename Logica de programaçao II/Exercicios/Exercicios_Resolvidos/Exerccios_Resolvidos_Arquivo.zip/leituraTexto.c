#include <stdio.h>

int main(){
   FILE *a;
   int idade;
   float salario;
   a = fopen("dados.txt","r+");
   if(a!=NULL){
        fseek(a,0,SEEK_SET);/*Posicionando no final do arquivo*/
        printf("\nDados do Arquivo\n");
        printf("Idade\tSal�rio\n");
        while(fscanf(a,"%d %f",&idade,&salario)==2)
          printf("%d\t%.2f\n",idade,salario);

      fclose(a);
   }
   else
      printf("\nErro na Abertura do Afrquivo!!!");
   return 0;
}
