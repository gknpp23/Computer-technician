#include <stdio.h>


int main(){
   FILE *a;
   int i, idade;
   float salario;

   a=fopen("saida.txt","r+");
   if(a==NULL)
      a=fopen("saida.txt","w+");

   if(a!=NULL){
      /*posiciona no final do arquivo,pois quero escrever no final.
      como o arquivo foi aberto para leitura e escrita o byte corrente
      � o primeiro do arquivo.*/
      fseek(a,0,SEEK_END);

      for(i=1;i<=3;i++){
         printf("\nForne�a a idade:");
         scanf("%d",&idade);
         printf("\nForne�a sal�rio:");
         scanf("%f",&salario);
         /*O espa�o entre o %d e %f � para separar os n�meros e o \n
         para escrever em outra linha*/
         fprintf(a,"%d %f\n",idade,salario);
      }

      /*posiciona no in�cio do arquivo*/
      fseek(a,0,SEEK_SET);

      while(fscanf(a,"%d %f",&idade,&salario)==2){

         printf("\n%d\t%f",idade,salario);
      }
      fclose(a);
   }
   else
      printf("\nErro na abertura do arquivo!!!\n");
}
