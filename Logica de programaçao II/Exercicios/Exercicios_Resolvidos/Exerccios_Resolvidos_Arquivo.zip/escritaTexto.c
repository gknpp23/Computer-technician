#include <stdio.h>

int main(){
   FILE *a;
   int sair,idade;
   float salario;
   a = fopen("dados.txt","r+");

   if (a==NULL)
      a = fopen("dados.txt","w+");
   if(a!=NULL){
      fseek(a,0,SEEK_END);/*Posicionando no final do arquivo*/
      do{
        printf("\nForne�a a Idade:");
        scanf("%d",&idade);
        printf("\nForne�a o Sal�rio:");
        scanf("%f",&salario);

        fprintf(a,"%d %.2f\n",idade,salario);
        printf("\nDeseja Sair? 1-Sim  2-N�o:");
        scanf("%d",&sair);
      }while(sair!=1);
      fclose(a);
   }
   else
      printf("\nErro na Abertura do Afrquivo!!!");
   return 0;
}
