/*Fa�a um programa que possua o menu:
1 � Cadastrar
2 � Consultar
3 � Alterar
4 - Listar
5 � Fim
caso a op��o selecionada seja:
1 � Permitir que se cadastre a matr�cula, nome e sal�rio dos funcion�rios.
Obs.:
A matr�cula � �nica
2 � Pedir ao usu�rio uma valor e mostrar os dados do funcion�rio que possua matr�cula igual ao valor
fornecido.
3 � Pedir ao usu�rio uma valor e alterar o nome e salario do funcion�rio que possua matr�cula igual ao valor fornecido.
4 � Listar os dados de todos os funcion�rios.*/

#include <stdio.h>
#include <locale.h>
#include <string.h>

typedef struct{
   int matricula;
   char nome[100];
   float salario;
}TFuncionario;


void retiraEnter(char s[]){
   if(s[strlen(s)-1]=='\n')
      s[strlen(s)-1]='\0';
}


/*Rotina que verifica a exis�ncia de um funcion�rio com determinada matr�cula.
Valoresde Retorno:
-1 caso n�o encontre ou a posi��o relativa do registro no caso de encontrar.
*/
int pesquisa(FILE *a, int mat){
   int posicao =0;
   TFuncionario r;
   /*posicionando no in�cio do arquivo*/
   fseek(a,0,SEEK_SET);
   /*rewind(a);*/
   while(fread(&r,sizeof(TFuncionario),1,a)==1){
      if(r.matricula==mat)
         return posicao;
      else
         posicao++;
   }
   return -1;
}
void cadastrar(FILE *a){
   int sair,m;
   TFuncionario rf;

   do{
      printf("\nForne�a a Matr�cula:");
      scanf("%d",&m);

      if(pesquisa(a,m)==-1){
         rf.matricula=m;
         setbuf(stdin,NULL);
         printf("Forne�a o Nome:");
         fgets(rf.nome,100,stdin);
         retiraEnter(rf.nome);
         setbuf(stdin,NULL);
         printf("Forne�a o Sal�rio:");
         scanf("%f",&rf.salario);
         /*posicionando no final do arquivo*/
         fseek(a,0,SEEK_END);
         fwrite(&rf,sizeof(TFuncionario),1,a);
      }
      else
        printf("\nMatr�cula Repetida!!!\n");

      printf("\nDeseja Abandonar o Cadastro? 1-Sim  2-N�o:");
      scanf("%d",&sair);

   }while(sair!=1);

}

void consultar(FILE *a){
   int sair,m,posicao;
   TFuncionario rf;
   /*Verificndo se o arquivo est� vazio*/
   fseek(a,0,SEEK_END);
   if(ftell(a)>0){
     do{
       printf("\nForne�a a Matr�cula:");
       scanf("%d",&m);
       posicao=pesquisa(a,m);

       if(posicao!= -1){
         /*posicionando no registro com o campo mat�ricula igual ao valor vari�vel m*/
         fseek(a,posicao*sizeof(TFuncionario),SEEK_SET);
         fread(&rf,sizeof(TFuncionario),1,a);
         printf("\nDados do Funcion�rio\n");

         printf("Mat�cula = %d",rf.matricula);
         printf("\nNome = %s",rf.nome);
         printf("\nSal�rio = %.2f",rf.salario);
       }
       else
         printf("\nMatr�cula Inexistente!!!\n");

       printf("\nDeseja Abandonar a Consulta? 1-Sim  2-N�o:");
       scanf("%d",&sair);

     }while(sair!=1);
   }
   else
      printf("\nNenhum Funcion]�rio Cadastrado!!");
}


void alterar(FILE *a){
   int sair,m,posicao;
   TFuncionario rf;
   do{
     printf("\nForne�a a Matr�cula:");
     scanf("%d",&m);
     posicao=pesquisa(a,m);

     if(posicao!= -1){
        printf("\nForne�a o novo nome:");
        setbuf(stdin,NULL);
        fgets(rf.nome,100,stdin);
        retiraEnter(rf.nome);
        setbuf(stdin,NULL);
        printf("Forne�a o novlo sal�rio:");
        scanf("%f",&rf.salario);
        rf.matricula=m;

        /*posicionando no registro com o campo mat�ricula igual ao valor vari�vel m*/
        fseek(a,posicao*sizeof(TFuncionario),SEEK_SET);
        fwrite(&rf,sizeof(TFuncionario),1,a);

     }
     else
        printf("\nMatr�cula Inexistente!!!\n");

     printf("\nDeseja Abandonar a Altera��o? 1-Sim  2-N�o:");
     scanf("%d",&sair);

   }while(sair!=1);
}

void listar(FILE *a){
   TFuncionario rf;

   fseek(a,0,SEEK_SET);
   printf("\nMatr�cula\tNome\t\t\t\tSal�rio\n");
   while(fread(&rf,sizeof(TFuncionario),1,a)==1)
      printf("%d\t%s\t\t\t\t%.2f\n",rf.matricula,rf.nome,rf.salario);
}

int main(){
   FILE *arq;
   int opcao;

   setlocale(LC_ALL,"Portuguese");

   arq=fopen("dados.dat","rb+");
   if(arq==NULL)
     arq=fopen("dados.dat","wb+");
   printf("\nN�mero de Registros no Arquivo = %d\n",)
   if (arq!=NULL){
     do{
       printf("\n1-Cadastrar\n2-Consultar\n3-Alterar\n4-Listar\n5-Fim\n");
       printf("Forne�a sua op��o:");
       scanf("%d",&opcao);

       switch(opcao){
       case 1:
         cadastrar(arq);
         break;
       case 2:
          consultar(arq);
          break;
       case 3:
          alterar(arq);
          break;
       case 4:
          listar(arq);
          break;

       }
     }while(opcao!=5);
     fclose(arq);
   }
   else
      printf("\nErro na abertura do arquivo!!!");
   return 0;
}
